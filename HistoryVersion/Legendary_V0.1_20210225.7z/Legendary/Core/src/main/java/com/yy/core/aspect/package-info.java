/**
 * package-info: 自定义注解
 *
 *      1、RedisCache：Redis缓存切面
 *      2、Exception：异常切面
 *
 *
 *
 *
 *
 *
 * @Author: YangYang
 * @Date: 2021/2/24 11:55
 */
package com.yy.core.aspect;