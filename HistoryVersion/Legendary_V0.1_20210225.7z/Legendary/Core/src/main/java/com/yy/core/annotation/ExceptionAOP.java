package com.yy.core.annotation;

/**
 * ExceptionAOP: 自定义异常拦截注解
 *
 * @Author: YangYang
 * @Date: 2021/2/24 14:59
 */
public @interface ExceptionAOP {
    String values() default "";

    String description() default "自定义异常拦截注解";
}
