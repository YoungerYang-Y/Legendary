package com.yy.mbg.domain.service;

import com.yy.mbg.domain.entity.SysRole;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 角色表 服务类
 * </p>
 *
 * @author YangYang
 * @since 2021-02-19
 */
public interface ISysRoleService extends IService<SysRole> {

}
