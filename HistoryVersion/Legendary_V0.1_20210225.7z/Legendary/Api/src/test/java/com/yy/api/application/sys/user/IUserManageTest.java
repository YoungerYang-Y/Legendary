package com.yy.api.application.sys.user;

import com.yy.api.TestAbstract;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.Assert.*;

/**
 * IUserManageTest:
 *
 * @Author: YangYang
 * @Date: 2021/2/24 11:45
 */
@Slf4j
public class IUserManageTest extends TestAbstract {

    @Autowired
    private IUserManage userManage;

    @Test
    public void disableUser() {

        try {
            userManage.disableUser(1);
        }
        catch (Exception e){

        }
    }
}