package com.yy.api.mapper;

import com.yy.api.TestAbstract;
import com.yy.api.application.sys.user.mapper.UserPermissionMapper;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * UserPermissionMapperTest:
 *
 * @Author: YangYang
 * @Date: 2021/2/23 22:43
 */
@Slf4j
public class UserPermissionMapperTest extends TestAbstract {

    @Autowired
    private UserPermissionMapper mapper;

    @Test
    public void getUserPermission() {
        log.info(mapper.getUserPermission(1).toString());
    }
}