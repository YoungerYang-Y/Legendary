package com.yy.api.application.impl;

import com.yy.api.TestAbstract;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * ApiTestTest:
 *
 * @Author: YangYang
 * @Date: 2021/2/13 11:49
 */
@Slf4j
class ApiTestTest extends TestAbstract {


    @Test
    void getAll() {
        log.error("COLOR ERROR");
        log.warn("COLOR WARN");
        log.info("COLOR INFO");
        log.debug("COLOR DEBUG");
        log.trace("COLOR TRACE");
    }
}