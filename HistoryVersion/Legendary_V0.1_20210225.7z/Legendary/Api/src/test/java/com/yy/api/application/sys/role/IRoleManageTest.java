package com.yy.api.application.sys.role;

import com.yy.api.TestAbstract;
import com.yy.api.application.sys.role.dto.RoleParam;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.Assert.*;

/**
 * IRoleManageTest:
 *
 * @Author: YangYang
 * @Date: 2021/2/22 11:11
 */
@Slf4j
public class IRoleManageTest extends TestAbstract {

    @Autowired
    private IRoleManage roleManage;

    @Test
    public void list() {
        log.info(roleManage.list().toString());
    }

    @Test
    public void addRole() {
        RoleParam roleParam = new RoleParam();
        roleParam.setName("测试角色");
        roleParam.setStatus(1);
        roleManage.addRole(roleParam);
    }

    @Test
    public void changeRole() {
        RoleParam roleParam = new RoleParam();
        roleParam.setName("测试角色change");
        roleManage.changeRole(roleParam,5);
    }

    @Test
    public void removeRole() {
        roleManage.removeRole(5);
    }
}