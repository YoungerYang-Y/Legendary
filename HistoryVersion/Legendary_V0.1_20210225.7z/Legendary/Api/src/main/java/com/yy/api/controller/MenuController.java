package com.yy.api.controller;

import com.yy.api.application.sys.menu.IMenuManage;
import com.yy.api.application.sys.menu.dto.MenuParam;
import com.yy.api.application.sys.menu.dto.MenuTree;
import com.yy.api.common.CommonResult;
import com.yy.core.annotation.ExceptionAOP;
import com.yy.core.annotation.RedisCache;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * MenuController: 菜单管理接口
 *
 * @Author: YangYang
 * @Date: 2021/2/22 8:51
 */
@Api(tags = "菜单接口")
@RestController
@RequestMapping("/sys/menu")
public class MenuController {

    @Autowired
    private IMenuManage menuManage;

    // TODO: 鉴权 @PreAuthorize("hasAuthority('pms:brand:read')")


    @ExceptionAOP
    @ApiOperation("添加菜单")
    @PostMapping(value = "/create")
    public CommonResult<MenuParam> addMenu(@RequestBody MenuParam menuParam) {

        if (menuManage.addMenu(menuParam)){
            return CommonResult.success(menuParam);
        }
        else{
            return CommonResult.failed("操作失败");
        }
    }


    @ExceptionAOP
    @RedisCache
    @ApiOperation("修改菜单基础信息")
    @PutMapping(value = "/update/{id}")
    public CommonResult<MenuParam> changeMenu(@PathVariable("id") Integer id, @RequestBody MenuParam menuParam) {

        if (menuManage.changeMenu(menuParam,id)){
            return CommonResult.success(menuParam);
        }
        else{
            return CommonResult.failed("操作失败");
        }
    }

    @ExceptionAOP
    @RedisCache
    @ApiOperation("删除菜单")
    @DeleteMapping(value = "/delete/{id}")
    public CommonResult deleteMenu(@PathVariable("id") Integer id) {

        if (menuManage.removeMenu(id)){
            return CommonResult.success(null);
        }
        else{
            return CommonResult.failed("操作失败");
        }
    }

    @RedisCache
    @ApiOperation("修改菜单启用状态")
    @PutMapping(value = "/update/{id}/{status}")
    public CommonResult<MenuParam> changeMenuStatus(@PathVariable("id") Integer id, @PathVariable("status") Integer status) {

        MenuParam menuParam = new MenuParam();
        menuParam.setStatus(status);
        if (menuManage.changeMenu(menuParam,id)){
            return CommonResult.success(menuParam);
        }
        else{
            return CommonResult.failed("操作失败");
        }
    }
}
