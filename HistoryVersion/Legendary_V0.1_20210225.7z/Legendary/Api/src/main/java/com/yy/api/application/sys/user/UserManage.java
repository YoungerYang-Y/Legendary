package com.yy.api.application.sys.user;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.yy.api.application.sys.menu.dto.MenuTree;
import com.yy.api.application.sys.menu.dto.PermissionDto;
import com.yy.api.application.sys.menu.util.MenuTreeUtil;
import com.yy.api.application.sys.role.dto.RoleDto;
import com.yy.api.application.sys.user.dto.UserDto;
import com.yy.api.application.sys.user.dto.UserParam;
import com.yy.api.application.sys.user.mapper.UserRoleMapper;
import com.yy.api.application.sys.user.mapper.UserPermissionMapper;
import com.yy.api.common.CommonConst;
import com.yy.core.annotation.RedisCache;
import com.yy.core.utils.ListSortUtil;
import com.yy.mbg.domain.entity.SysUser;
import com.yy.mbg.domain.entity.SysUserRoleRelation;
import com.yy.mbg.domain.service.ISysUserRoleRelationService;
import com.yy.mbg.domain.service.ISysUserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

/**
 * UserManage: 用户管理
 *
 * @Author: YangYang
 * @Date: 2021/2/19 17:16
 */
@Slf4j
@Component
public class UserManage implements IUserManage {

    @Autowired
    private ISysUserRoleRelationService roleRelationService;
    @Autowired
    private ISysUserService userService;
    @Autowired
    private UserPermissionMapper userPermissionMapper;
    @Autowired
    private UserRoleMapper userRoleMapper;

    @Override
    public boolean addUser(UserParam userParam) {

        // 检查用户名是否重复
        String username = userParam.getUsername();
        QueryWrapper<SysUser> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username",username);
        SysUser one = userService.getOne(queryWrapper);
        if (BeanUtil.isEmpty(one)){
            return false;
        }

        SysUser sysUser = new SysUser();
        BeanUtil.copyProperties(userParam, sysUser);
        sysUser.setGmtCreate(new Date());
        return userService.save(sysUser);
    }

    @RedisCache
    @Override
    public boolean changeUser(Integer id, UserParam userParam) {

        SysUser sysUser = userService.getById(id);
        sysUser.setUsername(userParam.getUsername());
        sysUser.setPassword(userParam.getPassword());
        sysUser.setBirthday(userParam.getBirthday());
        sysUser.setCity(userParam.getCity());
        sysUser.setEmail(userParam.getEmail());
        sysUser.setGender(userParam.getGender());
        sysUser.setIcon(userParam.getIcon());
        sysUser.setNickname(userParam.getNickname());
        sysUser.setPhone(userParam.getPhone());
        sysUser.setStatus(userParam.getStatus());
        sysUser.setGmtModified(new Date());
        return userService.updateById(sysUser);
    }

    @RedisCache
    @Override
    public boolean removeUser(Integer id) {

        return userService.removeById(id);
    }

    @Override
    public boolean disableUser(Integer id) {

        UpdateWrapper<SysUser> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id",id)
                .set("status",0);
        return userService.update(updateWrapper);
    }

    @Override
    public boolean enableUser(Integer id) {
        UpdateWrapper<SysUser> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id",id)
                .set("status",1);
        return userService.update(updateWrapper);
    }

    @RedisCache
    @Override
    public boolean changeRole(Integer userId, Integer roleId) {

        SysUserRoleRelation sysUserRoleRelation = new SysUserRoleRelation();
        sysUserRoleRelation.setRoleId(roleId);
        sysUserRoleRelation.setUserId(userId);
        return roleRelationService.save(sysUserRoleRelation);
    }

    @Override
    public boolean loginCheck(String username, String password) {

        QueryWrapper<SysUser> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username", username);
        SysUser user = userService.getOne(queryWrapper,true);
        if (BeanUtil.isEmpty(user)){
            return false;
        }
        else {
            // TODO: 判断密码，为考虑密码加密
            if (user.getPassword().compareTo(password) != 0){
                return false;
            }
        }

        return true;
    }

    @Override
    public void login(Integer id) {

        SysUser user = userService.getById(id);
        user.setLoginTime(new Date());
        userService.updateById(user);
    }

    @RedisCache
    @Override
    public UserDto getUser(Integer id) {

        SysUser sysUser = userService.getById(id);
        UserDto userDto = new UserDto();
        BeanUtil.copyProperties(sysUser,userDto);
        return userDto;
    }

    @Override
    public List<PermissionDto> getUserPermission(Integer id) {
        return userPermissionMapper.getUserPermission(id);
    }

    @Override
    public List<RoleDto> getUserRole(Integer id) {
        return userRoleMapper.getUserRoles(id);
    }

    @Override
    public List<MenuTree> getUserMenuTree(Integer id) {

        // 1、根据用户id获取符合条件的目录菜单权限集
        List<PermissionDto> list = userPermissionMapper.getUserMenu(id);
        // 2、生成菜单树
        return MenuTreeUtil.getMenu(list);
    }
}
