package com.yy.api.controller;

import com.yy.api.application.sys.role.IRoleManage;
import com.yy.api.application.sys.role.dto.RoleDto;
import com.yy.api.application.sys.role.dto.RoleParam;
import com.yy.api.common.CommonResult;
import com.yy.core.annotation.RedisCache;
import com.yy.mbg.domain.entity.SysRole;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * RoleController: 角色管理
 *
 * @Author: YangYang
 * @Date: 2021/2/22 11:25
 */
@Api(tags = "角色管理")
@RestController
@RequestMapping("/sys/role")
public class RoleController {

    @Autowired
    private IRoleManage roleManage;

    @ApiOperation("获取所有角色信息")
    @GetMapping("/list")
    public CommonResult<List<SysRole>> getList(){

        return CommonResult.success(roleManage.list());
    }

    @ApiOperation("获取用户的角色信息")
    public CommonResult<List<RoleDto>> getUserRole(Integer id){
        return CommonResult.success(roleManage.getUserRole(id));
    }

    @ApiOperation("新增一个角色")
    @PostMapping("/create")
    public CommonResult addRole(RoleParam roleParam){

        if(roleManage.addRole(roleParam)){
            return CommonResult.success(null);
        }
        else{
            return CommonResult.failed("操作失败");
        }
    }

    @RedisCache
    @ApiOperation("修改角色信息")
    @PutMapping("/update/{id}")
    public CommonResult changeRole(@PathVariable("id") Integer id,RoleParam roleParam){

        if (roleManage.changeRole(roleParam,id)){
            return CommonResult.success(roleParam);
        }
        else{
            return CommonResult.failed("操作失败");
        }
    }

    @RedisCache
    @ApiOperation("删除角色")
    @DeleteMapping(value = "/delete/{id}")
    public CommonResult deleteMenu(@PathVariable("id") Integer id) {

        if (roleManage.removeRole(id)){
            return CommonResult.success(null);
        }
        else{
            return CommonResult.failed("操作失败");
        }
    }
}
