package com.yy.api.application.sys.role;

import cn.hutool.core.bean.BeanUtil;
import com.yy.api.application.sys.role.dto.RoleDto;
import com.yy.api.application.sys.role.dto.RoleParam;
import com.yy.api.application.sys.user.mapper.UserRoleMapper;
import com.yy.mbg.domain.entity.SysRole;
import com.yy.mbg.domain.service.ISysRoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

/**
 * RoleManage: 角色管理
 *
 * @Author: YangYang
 * @Date: 2021/2/19 17:17
 */
@Component
public class RoleManage implements IRoleManage {

    @Autowired
    private ISysRoleService roleService;
    @Autowired
    private UserRoleMapper userRoleMapper;


    @Override
    public List<SysRole> list() {
        return roleService.list();
    }

    @Override
    public List<RoleDto> getUserRole(Integer id) {

        return userRoleMapper.getUserRoles(id);
    }

    @Override
    public boolean addRole(RoleParam roleParam) {

        SysRole role = new SysRole();
        BeanUtil.copyProperties(roleParam,role);
        role.setGmtCreate(new Date());
        return roleService.save(role);
    }

    @Override
    public boolean changeRole(RoleParam roleParam, Integer id) {

        SysRole sysRole = roleService.getById(id);
        sysRole.setName(roleParam.getName());
        sysRole.setStatus(roleParam.getStatus());
        sysRole.setGmtModified(new Date());
        return roleService.updateById(sysRole);
    }

    @Override
    public boolean removeRole(Integer id) {

        return roleService.removeById(id);
    }
}
