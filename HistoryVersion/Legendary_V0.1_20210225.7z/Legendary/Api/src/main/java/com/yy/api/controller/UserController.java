package com.yy.api.controller;

import com.yy.api.application.sys.menu.dto.MenuTree;
import com.yy.api.application.sys.menu.dto.PermissionDto;
import com.yy.api.application.sys.role.dto.RoleDto;
import com.yy.api.application.sys.user.IUserManage;
import com.yy.api.application.sys.user.dto.UserDto;
import com.yy.api.common.CommonResult;
import com.yy.core.annotation.ExceptionAOP;
import com.yy.core.annotation.RedisCache;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * UserController:
 *
 * @Author: YangYang
 * @Date: 2021/2/24 22:38
 */
@Api(tags = "用户接口")
@RestController
@RequestMapping("/sys/user")
public class UserController {

    @Autowired
    private IUserManage userManage;

    // TODO 如果都在UserController中获取，当权限change或delete改动时Redis需要删除缓存


    @RedisCache
    @ApiOperation("获取用户的基本信息")
    @GetMapping(value = "/info/{id}")
    public CommonResult<UserDto> getUserInfo(@PathVariable("id") Integer id) {

        return CommonResult.success(userManage.getUser(id));
    }

    @RedisCache
    @ApiOperation("获取用户拥有的角色信息")
    @GetMapping(value = "/role/{id}")
    public CommonResult<List<RoleDto>> getUserRole(@PathVariable("id") Integer id) {

        return CommonResult.success(userManage.getUserRole(id));
    }

    @RedisCache
    @ApiOperation("获取用户的访问菜单结构")
    @GetMapping(value = "/menu/{id}")
    public CommonResult<List<MenuTree>> getMenuTree(@PathVariable("id") Integer id) {

        return CommonResult.success(userManage.getUserMenuTree(id));
    }

    @RedisCache
    @ApiOperation("获取用户的访问权限")
    @GetMapping(value = "/permission/{id}")
    public CommonResult<List<PermissionDto>> getUserPermission(@PathVariable("id") Integer id) {

        return CommonResult.success(userManage.getUserPermission(id));
    }
}
