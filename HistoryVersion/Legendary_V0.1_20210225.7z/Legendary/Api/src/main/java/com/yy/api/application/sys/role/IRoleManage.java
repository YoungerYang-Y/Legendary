package com.yy.api.application.sys.role;

import com.yy.api.application.sys.role.dto.RoleDto;
import com.yy.api.application.sys.role.dto.RoleParam;
import com.yy.mbg.domain.entity.SysRole;
import io.swagger.models.auth.In;

import java.util.List;

/**
 * IRoleManage: 角色管理
 *
 * @Author: YangYang
 * @Date: 2021/2/19 17:17
 */
public interface IRoleManage {

    // TODO: 分页page
    /**
     * 浏览所有角色信息
     *
     * @return 所有信息
     */
    List<SysRole> list();

    /**
     * 获取用户的所有角色信息
     *
     * @param id 用户id
     * @return 所有信息
     */
    List<RoleDto> getUserRole(Integer id);

    /**
     * 新增角色
     *
     * @param roleParam 角色信息参数
     * @return 返回执行结果
     */
    boolean addRole(RoleParam roleParam);

    /**
     * 修改角色信息
     *
     * @param roleParam 角色信息参数
     * @param id 角色id
     * @return 返回执行结果
     */
    boolean changeRole(RoleParam roleParam,Integer id);

    /**
     * 删除角色
     *
     * @param id 角色id
     * @return 返回执行结果
     */
    boolean removeRole(Integer id);
}
