package com.yy.api.application.sys.menu.dto;

import com.baomidou.mybatisplus.annotation.Version;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * MenuParam: 新增菜单参数
 *
 * @Author: YangYang
 * @Date: 2021/2/19 20:31
 */
@Getter
@Setter
public class MenuParam {

    @NotEmpty(message = "父类id不能为空")
    @ApiModelProperty(value = "父类id", required = true)
    private Integer pid;

    @NotEmpty(message = "菜单名称不能为空")
    @ApiModelProperty(value = "菜单名称", required = true)
    private String name;

    @ApiModelProperty(value = "权限值")
    private String value;

    @NotEmpty(message = "权限类型不能为空")
    @ApiModelProperty(value = "权限类型：0->目录；1->菜单；2->按钮（接口绑定权限）", required = true)
    private Integer type;

    @ApiModelProperty(value = "前端资源路径")
    private String uri;

    @ApiModelProperty(value = "菜单顺序")
    private Integer sort;

    @ApiModelProperty(value = "菜单图标")
    private String icon;

    @NotEmpty(message = "启用标志不能为空")
    @ApiModelProperty(value = "是否启用")
    private Integer status;

}
